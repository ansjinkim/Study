﻿import clr

clr.AddReference("VM.Post.API.Python")

from VM.Post.API.Python import ArithmeticIF

def IF(e1: str, e2: str, e3: str, e4: str) -> str:
    """
    The conditional function.
    :E1 : E1 can be defined as constant values.
    :E2 : E2 can be defined as constant values.
    :E3 : E3 can be defined as constant values.
    :E4 : E4 can be defined as constant values.
    :return : A value will be returned under condition.
    """
    s1 : float = e1
    s2 : float = e2
    s3 : float = e3
    s4 : float = e4
    
    #IF(1.0,0.0,0.0,DM("BD_02/CM","BD_03/CM"))

    #if s1 > 0:
    #    return s2

    #if s1 == 0:
    #    return s3

    #if s1 < 0 :
    #    return s4
    
    return ArithmeticIF.IF(s1,s2,s3,s4)