﻿import math
import clr

clr.AddReference("VM.Post.API.Python")

from VM.Post.API.Python import Predefined

def CHEBY(X : str,X0 : str,*CN : str) -> str:
    """
    Use to define the Chebyshev polynomial.
    :X : X is real or expression type and the independent variable of x. 
    :X0 : X0 is real or expression type and the offset of x0.
    :C0 : C0 is real or expression type and first polynomial coefficient of c0.
    :CN : C is real or expression type and last polynomial coefficient of cN. The number of polynomial is less than or equal to 31.
    :return: return value is f(x)
    """
    return Predefined.CHEBY(X,X0,CN)

def POLY(X : str, X0 : str, *CN : str) -> str:
    """
    Use to define the standard polynomial.
    :X : X is real or expression type and the independent variable of x. 
    :X0 : X0 is real or expression type and the offset of x0.
    :C0 : C0 is real or expression type and first polynomial coefficient of c0.
    :CN : C is real or expression type and last polynomial coefficient of cN. The number of polynomial is less than or equal to 31.
    :return: return value is f(x)
    """
    return Predefined.POLY(X,X0,CN)

def HAVSIN(X,X0,H0,X1,H1):
    """
    Use to define the haversine.
    :X  : X is real or expression type and the independent variable of x. 
    :X0 : X0 is real or expression type and the value of x0 at which the function starts.
    :H0 : H0 is real or expression type and initial value of h0.
    :X1 : X1 is real or expression type and the value of x1 at which the function ends.
    :H1 : H1 is real or expression type and final value of h1.
    :return: return value is f(x)
    """
    return Predefined.HAVSIN(X,X0,H0,X1,H1)

def STEP(X,X0,H0,X1,H1):
    """
    Use to define the approximated Heaviside step function with cubic polynomial.
    :X  : X is real or expression type and the independent variable of x. 
    :X0 : X0 is real or expression type and the value of x0 at which the function starts.
    :H0 : H0 is real or expression type and initial value of h0.
    :X1 : X1 is real or expression type and the value of x1 at which the function ends.
    :H1 : H1 is real or expression type and final value of h1.
    :return: return value is f(x)
    """
    return Predefined.STEP(X,X0,H0,X1,H1)

def FORCOS(X, X0, Freq, *CN):
    """
    Use to define the furrier cosine series.
    :X  : X is real or expression type and the independent variable of x.
    :X0 : X0 is real or expression type and the offset of x0.
    :Freq : Freq is real or expression type and frequency of w.
    :C0 : C0 is real or expression type and first amplitude of c0.
    :CN : EN is real or expression type and last amplitude of Cn. The number of series is less than or equal to 31.
    :return: return value is f(x)
    """
    return Predefined.FORCOS(X, X0, Freq, CN)

def FORSIN(X, X0, Freq, *CN):
    """
    Use to define the furrier sine series.
    :X  : X is real or expression type and the independent variable of x.
    :X0 : X0 is real or expression type and the offset of x0.
    :Freq : Freq is real or expression type and frequency of w.
    :C0 : C0 is real or expression type and first amplitude of c0.
    :CN : EN is real or expression type and last amplitude of Cn. The number of series is less than or equal to 31.
    :return: return value is f(x)
    """
    return Predefined.FORSIN(X, X0, Freq, CN)

def SHF(X, X0, A, Freq, Phase, Disp):
    """
    Use to define the simple harmonic function.
    :X : X1 is real or expression type and the independent variable of x. 
    :X0 : X0 is real or expression type and the offset of x0.
    :Ampl : A is real or expression type and amplitude of A.
    :Freq : Freq is real or expression type and frequency of w.
    :Phase : E5 is real or expression type and phase angle of Φ.
    :Disp is real or expression type and mean value of y0.
    :return: return value is f(x)
    """
    return Predefined.SHF(X, X0, A, Freq, Phase, Disp)

def IMPACT(X, Xdot, X1, K, Exp, Cmax, D):

    """
    Use to define the impact function as following equations. When the independent variable is a function of distance, this function can represent a simple contact force.
    :X : X is real or expression type and the independent variable of x. Maybe this variable will be a displacement function.
    :Xdot : Xdot is real or expression type and the time derivative of x.
    :X1 : E3 is real type and the radius of x1. When the independent variable of x is less than this value.
    :K : K is non-negative real type and the contact stiffness of k.
    :Exp : Exp is positive real type and the contact exponent of e.
    :Cmax : Cmax is non-negative real type and the maximum damping coefficient of cmax.
    :D : D is positive real type and the boundary penetration of d.
    """
    return Predefined.IMPACT(X, Xdot, X1, K, Exp, Cmax, D)

def BISTOP(X, Xdot, X1, X2, K, Exp, Cmax, D):
    """
    Use to define the bitstop function as following equations. When the independent variable is a function of distance.
    :X : X is real or expression type and the independent variable of x. Maybe this variable will be a displacement function.
    :Xdot : Xdot is real or expression type and the time derivative of x.
    :X1 : X1 is real type and the radius of x1. When the independent variable of x is less than this value.
    :X2 : X2 is real type and the radius of x2. When the independent variable of x is less than this value.
    :K : K is non-negative real type and the contact stiffness of k.
    :Exp : Exp is positive real type and the contact exponent of e.
    :Cmax : Cmax is non-negative real type and the maximum damping coefficient of cmax.
    :D : D is positive real type and the boundary penetration of d.
    :retur : return value is f(x)
    """
    return Predefined.BISTOP(X, Xdot, X1, X2, K, Exp, Cmax, D)

def PLANK(X, Start, Length, B_length, Height):
    """
    Use to define the plank function as following equations. When the independent variable is a function of distance.
    :X : X is real or expression type and the independent variable of x. Maybe this variable will be a displacement function.
    :Start : Start is real type and the starting length of xs. When the independent variable of x is less than this value, the function is will return zero.
    :Length : Length is real type and the bump length of L.
    :B_length : B_length is real type and the beveled length of bl.
    :Height : Height is real type and the bump height of h.
    :return : return value is f(x)
    """
    return Predefined.PLANK(X, Start, Length, B_length, Height)

def ROOF(X, Start, Length, Height):
    """
    Use to define the roof function as following equations. When the independent variable is a function of distance.
    :X : X is real or expression type and the independent variable of x. Maybe this variable will be a displacement function.
    :Start : Start is real type and the starting length of xs. When the independent variable of x is less than this value, the function is will return zero.
    :Length : Length is real type and the bump length of L.
    :Height : Height is real type and the bump height of h.
    :return : return value is f(x)

    """
    return Predefined.ROOF(X, Start, Length, Height)

def STEP0(X,X0,DX,H):
    """
    Use to define the step function without a transition.
    :X : X is real or expression type and the independent variable of x. 
    :X0 : X0 is real type and the starting length of . When the independent variable of is less than this value.
    :DX : DX is real type and the length of L.
    :H : H is real type and the height of h.
    :return: return value is f(x)
    """
    return Predefined.STEP0(X,X0,DX,H)

def SWEEP(X, A, X0, F0, X1, F1, Fc):
    """
    Use to define the sweep function which generates a sine wave in the range of specified start and end frequencies with linear sweep rate.
    :X : X is real or expression type and the independent variable of x. This value must be greater than or equal to zero. In general, the variable may be defined as a time.
    :A : A is real type and the amplitude of A.
    :X0 : X0 is real type and the starting variable of x0. This value must be greater than or equal to zero.
    :F0 : F0 is real type and the starting frequency of f0. This value must be greater than zero.
    :X1 : X1 is real type and the ending variable of x1. This value must be greater than the starting variable.
    :F1 : F1 is real type and the ending frequency of f1. This value must be greater than zero.
    :Fc : Fc is real type and the stepsize of Δt which is not used in ANSYS Motion/Solver.
    :return: return value is y(x)
    """
    return Predefined.SWEEP(X, A, X0, F0, X1, F1)

def SINE_SWEEP(X, A, X0, F0, X1, F1, Fc, Type):
    """
    Use to define the advanced sweep function which generates a sine wave in the range of specified start and end frequencies with linear and logarithm sweep rate.
    :X : X is real or expression type and the independent variable of x. This value must be greater than or equal to zero. In general, the variable may be defined as a time.
    :A : A is real type and the amplitude of A.
    :X0 : X0 is real type and the starting variable of x0. This value must be greater than or equal to zero.
    :F0 : F0 is real type and the starting frequency of f0. This value must be greater than zero.
    :X1 : X1 is real type and the ending variable of x1. This value must be greater than the starting variable.
    :F1 : F1 is real type and the ending frequency of f1. This value must be greater than zero.
    :Fc : Fc is real type and the cut-off frequency of fc. This value must be greater than zero. 
    :Type : Type is integer type and the sweep rate type. When this is 1, the linear sweep rate is used in the function. When this is 2, the logarithm sweep rate is used in the function.
    :return: return value is y(x)
    """
    return Predefined.SINE_SWEEP(X, A, X0, F0, X1, F1, Fc, Type)