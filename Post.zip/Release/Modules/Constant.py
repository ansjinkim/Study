﻿import clr

clr.AddReference("VM.Models.Post")

from VM.Models.Post import PythonExpression

DTOR = 0
PI = 0
RTOD = 0
TIME = 0