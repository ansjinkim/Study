﻿import clr

clr.AddReference("VM.Models.Post.EntityTypes")

from VM.Models.Post.EntityTypes.SubEntities import PythonExpression

DTOR = 0
PI = 0
RTOD = 0
TIME = 0