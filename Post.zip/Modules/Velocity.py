﻿import clr

clr.AddReference("VM.Post.API.Python")

from VM.Post.API.Python import Velocity

def VM(marker1, marker2 = None):
    """
    The magnitude of the relative velocity between markers.
    :Input (marker1, marker2) : marker1 and marker2 are the names of action and base markers. 
    :return:  the magnitude of the vector can be returned.
    """

    return Velocity.VM(marker1, marker2)

def VR(marker1, marker2 = None):
    """
    The relative velocity along to the relative displacement between two markers.
    :Input (marker1, marker2) : marker1 and marker2 are the names of action and base markers. 
    :return: The relative velocity in Eq. 8-15 will be returned.
    """

    return Velocity.VR(marker1, marker2)

def VX(marker1, marker2 = None, marker3 = None):
    """
    The x component of the relative velocity between markers
    :Input (marker1, marker2, marker3) : marker1, marker2 and marker3 are the names of action, base and reference markers. 
    :return: the x component of the vector can be returned
    """

    return Velocity.VX(marker1, marker2, marker3)

def VY(marker1, marker2 = None, marker3 = None):
    """
    The y component of the relative velocity between markers.
    :Input (marker1, marker2, marker3) : marker1, marker2 and marker3 are the names of action, base and reference markers. 
    :return: the y component of the vector can be returned
    """

    return Velocity.VY(marker1, marker2, marker3)

def VZ(marker1, marker2 = None, marker3 = None):
    """
    The z component of the relative velocity between markers.
    :Input (marker1, marker2, marker3) : marker1, marker2 and marker3 are the names of action, base and reference markers. 
    :return: the z component of the vector can be returned 
    """

    return Velocity.VZ(marker1, marker2, marker3)

def WM(marker1, marker2 = None):
    """
    The magnitude of the relative angular velocity between markers.
    :Input (marker1, marker2) : marker1 and marker2 are the names of action and base markers. 
    :return:  the magnitude of the vector can be returned
    """

    return Velocity.WM(marker1, marker2)

def WX(marker1, marker2 = None, marker3 = None):
    """
    The x component of the relative angular velocity between markers.
    :Input (marker1, marker2, marker3) : marker1, marker2 and marker3 are the names of action, base and reference markers. 
    :return: the x component of the vector can be returned
    """

    return Velocity.WX(marker1, marker2, marker3)

def WY(marker1, marker2 = None, marker3 = None):
    """
    The y component of the relative angular velocity between markers.
    :Input (marker1, marker2, marker3) : marker1, marker2 and marker3 are the names of action, base and reference markers. 
    :return: the y component of the vector can be returned
    """

    return Velocity.WY(marker1, marker2, marker3)

def WZ(marker1, marker2 = None, marker3 = None):
    """
    The z component of the relative angular velocity between markers.
    :Input (marker1, marker2, marker3) : marker1, marker2 and marker3 are the names of action, base and reference markers. 
    :return: the z component of the vector can be returned
    """

    return Velocity.WZ(marker1, marker2, marker3)