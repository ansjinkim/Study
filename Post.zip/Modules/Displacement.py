﻿import clr

clr.AddReference("VM.Post.API.Python")

from VM.Post.API.Python import Displacement

def DM(marker1, marker2 = None):
    """
    The magnitude of the relative position between markers.
    :Input (marker1, marker2) : marker1 and marker2 are the names of action and base markers.
    :return: the magnitude of the vector can be returned
    """
    return Displacement.DM(marker1, marker2)

def DX(marker1, marker2 = None, marker3 = None):
    """
    The x component of the relative position between markers.
    :Input (marker1, marker2, marker3) : marker1, marker2 and marker3 are the names of action, base and reference markers.
    :return: the x component of the vector can be returned
    """
    return Displacement.DX(marker1, marker2, marker3)

def DY(marker1, marker2 = None, marker3 = None):
    """
    The y component of the relative position between markers.
    :Input (marker1, marker2, marker3) : marker1, marker2 and marker3 are the names of action, base and reference markers.
    :return: the y component of the vector can be returned
    """
    return Displacement.DY(marker1, marker2, marker3)

def DZ(marker1, marker2 = None, marker3 = None):
    """
    The z component of the relative position between markers.
    :Input (marker1, marker2, marker3) : marker1, marker2 and marker3 are the names of action, base and reference markers.
    :return: the z component of the vector can be returned
    """
    return Displacement.DZ(marker1, marker2, marker3)

def PSI(marker1, marker2 = None):
    """
    The first rotation angle from ZXZ Euler angle.
    :Input (marker1, marker2) : marker1 and marker2 are the names of action and base markers.
    :return: The angle will be returned in radian.
    """
    return Displacement.PSI(marker1, marker2)

def THETA(marker1, marker2 = None):
    """
    The second rotation angle from ZXZ Euler angle.
    :Input (marker1, marker2) : marker1 and marker2 are the names of action and base markers.
    :return: The angle will be returned in radian.
    """
    return Displacement.THETA(marker1, marker2)

def PHI(marker1, marker2 = None):
    """
    The third rotation angle from ZXZ Euler angle.
    :Input (marker1, marker2) : marker1 and marker2 are the names of action and base markers.
    :return: The angle will be returned in radian.
    """
    return Displacement.PHI(marker1, marker2)

def YAW(marker1, marker2 = None):
    """
    The first rotation angle from ZYX Euler angle. In general sense, this can represent a relative angle between two markers with respect to the z-axis of the base marker.
    :Input (marker1, marker2) : marker1 and marker2 are the names of action and base markers.
    :return: The angle in Eq. 8-7 will be returned in radian.
    """
    return Displacement.YAW(marker1, marker2)

def PITCH(marker1, marker2 = None):
    """
    The second rotation angle from ZYX Euler angle. In general sense, this can represent a relative angle between two markers with respect to the y-axis of the base marker.
    :Input (marker1, marker2) : marker1 and marker2 are the names of action and base markers.
    :return: The angle will be returned in radian.
    """
    return Displacement.PITCH(marker1, marker2)

def ROLL(marker1, marker2 = None):
    """
    The third rotation angle from ZYX Euler angle. In general sense, this can represent a relative angle between two markers with respect to the x-axis of the base marker.
    :Input (marker1, marker2) : marker1 and marker2 are the names of action and base markers.
    :return: The angle will be returned in radian.
    """
    return Displacement.ROLL(marker1, marker2)