﻿import clr

clr.AddReference("VM.Post.API.Python")

from VM.Post.API.Python import SystemElement

def VARVAL(E1):
    """
    The variable of the variable equation.
    :Input (E1) : E1 is the names or argument ids of the variable equation.
    :return: The value of the variable equation will be returned.
    """
    return SystemElement.VARVAL(E1)

def DIF10(E1):
    """
    The integrated variable of the 1st order differential equation.
    :Input (E1) : E1 is the names or argument ids of the 1st order differential equation.
    :return: The value of the 1st order differential equation. will be returned.
    """
    return SystemElement.DIF10(E1)

def DIF11(E1):
    """
    The differential variable of the 1st order differential equation.
    :Input (E1) : E1 is the names or argument ids of the 1st order differential equation. 
    :return: The value of the 1st order differential equation. will be returned.
    """
    return SystemElement.DIF11(E1)

def DIF20(E1):
    """
    The double integrated variable of the 2nd order differential equation.
    :Input (E1) : E1 is the names or argument ids of the 2nd order differential equation. 
    :return:
    """
    return SystemElement.DIF20(E1)

def DIF21(E1):
    """
    The integrated variable of the 2nd order differential equation.
    :Input (E1) : E1 is the names or argument ids of the 2nd order differential equation. 
    :return:
    """
    return SystemElement.DIF21(E1)

def DIF22(E1):
    """
    The differential variable of the 2nd order differential equation.
    :Input (E1) : E1 is the names or argument ids of the 2nd order differential equation. 
    :return:
    """
    return SystemElement.DIF22(E1)