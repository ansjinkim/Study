﻿import math
import clr

clr.AddReference("VM.Post.API.Python")

from VM.Post.API.Python import PythonMath

def ABS(x):
    """
    Use to compute the absolute value of x.
    :Input (x) : Real.
    :return: Real ≥ 0.
    """
    return math.fabs(x)

def ACOS(x):
    """
    Use to compute the arccosine of x.
    :Input (x) : -1 ≤ Real ≤ 1. If the input value is greater than 1 or less than -1, it will be limited 1 or -1, respectively.
    :return: 0 ≤ Real < PI in Radian
    """
    return math.acos(x)

def AINT(x):
    """
    Use to truncate x to the whole number.
    :Input (x) : Real.
    :return: Integer. If the magnitude of x is less than 1, then AINT(x) 
            returns 0. If the magnitude is equal to or greater than 1, then it 
            returns the largest whole number that does not exceed its 
            magnitude. The sign is the same as the sign of x. 
    """

    return PythonMath.AINT(x)

def ANINT(x):
    """
    Use to round x to the nearest whole number
    :Input (x) : Real.
    :return: Integer. If x is greater than 0, then ANINT(X) returns 
            AINT(x+0.5). If x is less than or equal to 0, then return 
            AINT(x-0.5). 
    """
    return PythonMath.ANINT(x)

def ASIN(x):
    """
    Use to compute the arcsine of x.
    :Input (x) : -1 ≤ Real ≤ 1. If the input value is greater than 1 or less than -1, it will be limited 1 or -1, respectively.
    :return: -PI/2 ≤ Real ≤ PI/2 in Radian.
    """
    return math.asin(x)

def ATAN(x):
    """
    Use to compute the arctangent of x.
    :Input (x) : Real.
    :return: -PI/2 ≤ Real ≤ PI/2 in Radian.
    """
    return math.atan(x)

def ATAN2(x,y):
    """
    Use to compute the arctangent of y/x.
    :Input (x, y) : Real.
    :return: -PI < Real ≤ PI in Radian. The return value can be computed under several conditions as follows.
    1) x > 0 → ATAN(y/x)
    2) x < 0 & y ≥ 0 → ATAN(y/x) + PI
    3) x < 0 & y ≤ 0 → ATAN(y/x) - PI
    4) x = 0 & y > 0 → PI/2
    5) x = 0 & y < 0 → -PI/2
    6) x = 0 & y = 0 → 0
    """
    return math.atan2(y, x)

def CEIL(x):
    """
    Use to return the least integer greater than or equal to x.
    :Input (x) : Real.
    :return: Integer.
    """
    return math.ceil(x)

def COS(x):
    """
    Use to compute the cosine of x.
    :Input (x) : Real in Radian.
    :return: Real.
    """
    return math.cos(x)

def COSH(x):
    """
    Use to compute the hyperbolic cosine of x.
    :Input (x) : Real in Radian.
    :return: Real.
    """
    return math.cosh(x)

def DIM(x,y):
    """
    Use to compute the difference x-y if the result is positive. Otherwise returns zero.
    :Input (x, y) : Real.
    :return: Real ≥ 0.
    :exceptions:
    """

    return PythonMath.DIM(x,y)

def EXP(x):
    """
    Use to compute the base e exponential of x.
    :Input (x) : Real.
    :return: Real.
    """
    return math.exp(x)

def FLOOR(x):
    """
    Use to return the greatest integer less than or equal to x.
    :Input (x) : Real.
    :return: Integer.
    """
    return math.floor(x)

def INT(x):
    """
    Use to truncate x to the whole number.
    :Input (x) : Real.
    :return: Integer. If the magnitude of x is less than 1, then AINT(x) 
            returns 0. If the magnitude is equal to or greater than 1, then it 
            returns the largest whole number that does not exceed its 
            magnitude. The sign is the same as the sign of x. 
    """
    return PythonMath.AINT(x)

def LOG(x):
    """
    Use to compute the natural (i.e. base e) logarithm of x.
    :Input (x) : Real > 0.
    :return: Real.
    """
    return math.log(x)

def LOG10(x):
    """
    Use to compute the base 10 logarithm of x.
    :Input (x) : Real > 0
    :return: Real.
    """
    return math.log10(x)

def MAX(x,y):
    """
    Use to return the maximum value of x and y.
    :Input (x, y) : Real.
    :return: Real.
    """
    return PythonMath.MAX(x,y)

def MIN(x,y):
    """
    Use to return the minimum value of x and y.
    :Input (x, y) : Real.
    :return: Real.
    """
    return PythonMath.MIN(x,y)

def MOD(x,y):
    """
    Use to computes the remainder of the division of x by y.
    :Input (x, y) : Real. y must be not equal to zero.
    :return: Real.
    """
    return PythonMath.MOD(x,y)

def POW(x,y):
    """
    Use to computes x raised to the power of y.
    :Input (x, y) : Real. x must be not equal to zero
    :return: Real. The return value can be computed under several 
            conditions as follows.
            1) x > 0 → x^y
            2) x = 0 & y > 0 → 0
            3) x = 0 & y = 0 → 1
            4) x = 0 & y < 0 → 0
            5) x < 0 & y is a integer number. → x^y
            6) x < 0 & y has a finite decimal. → 0
            For 4) case and 6) cases, the return value is not calculated but 
            actually ANSYS Motion/Solver returns zero value.
    """
    return math.pow(x,y)

def RAND(x,y):
    """
    Use to returns a pseudo-random number from a uniform distribution between x and y.
    :Input (x, y) : Real. y must be greater than x.
    :return: Real.
    """
    return PythonMath.RAND(x,y)

def SIGN(x,y):
    """
    Use to return the value of x with the sign of y.
    :Input (x, y) : Real
    :return: Real.
    """

    return PythonMath.SIGN(x,y)

def SIN(x):
    """
    Use to compute the sine of x.
    :Input (x) : Real in Radian.
    :return: Real.
    """
    return math.sin(x)

def SINH(x):
    """
    Use to compute the hyperbolic sine of x.
    :Input (x) : Real in Radian.
    :return: Real.
    """
    return math.sinh(x)

def SQRT(x):
    """
    Use to compute the square root of x
    :Input (x) : Real ≥ 0.
    :return: Real ≥ 0.
    """
    return math.sqrt(x)

def TAN(x):
    """
    Use to compute the tangent of x.
    :Input (x) : Real in Radian. x must be not equal to (2N-1)*PI/2.
    :return: Real.
    """
    return math.tan(x)

def TANH(x):
    """
    Use to compute the hyperbolic tangent of x.
    :Input (x) : Real in Radian.
    :return: Real.
    """
    return math.tanh(x)