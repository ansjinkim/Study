﻿import clr

clr.AddReference("VM.Post.API.Python")

from VM.Post.API.Python import Acceleration

def ACCM(marker1, marker2 = None):
    """
    The magnitude of the relative acceleration between markers.
    :Input (marker1, marker2) : marker1 and marker2 are the names of action and base markers. 
    :return: the magnitude of the vector can be returned
    """

    return Acceleration.ACCM(marker1, marker2)

def ACCX(marker1, marker2 = None, marker3 = None):
    """
    The x component of the relative acceleration between markers.
    :Input (marker1, marker2, marker3) : marker1, marker2 and marker3 are the names of action, base and reference markers.
    :return: the x component of the vector can be returned
    """

    return Acceleration.ACCX(marker1, marker2, marker3)

def ACCY(marker1, marker2 = None, marker3 = None):
    """
    The y component of the relative acceleration between markers.
    :Input (marker1, marker2, marker3) : marker1, marker2 and marker3 are the names of action, base and reference markers. 
    :return: the y component of the vector can be returned
    """

    return Acceleration.ACCY(marker1, marker2, marker3)

def ACCZ(marker1, marker2 = None, marker3 = None):
    """
    The z component of the relative acceleration between markers.
    :Input (marker1, marker2, marker3) : marker1, marker2 and marker3 are the names of action, base and reference markers. 
    :return: the z component of the vector can be returned
    """

    return Acceleration.ACCZ(marker1, marker2, marker3)

def WDTM(marker1, marker2 = None):
    """
    The magnitude of the relative angular acceleration between markers.
    :Input (marker1, marker2) : marker1 and marker2 are the names of action and base markers. 
    :return: the magnitude of the vector can be returned
    """

    return Acceleration.WDTM(marker1, marker2)

def WDTX(marker1, marker2 = None, marker3 = None):
    """
    The x component of the relative angular acceleration between markers.
    :Input (marker1, marker2, marker3) : marker1, marker2 and marker3 are the names of action, base and reference markers.
    :return: the x component of the vector can be returned
    """

    return Acceleration.WDTX(marker1, marker2, marker3)

def WDTY(marker1, marker2 = None, marker3 = None):
    """
    The y component of the relative angular acceleration between markers.
    :Input (marker1, marker2, marker3) : marker1, marker2 and marker3 are the names of action, base and reference markers.
    :return: the y component of the vector can be returned
    """

    return Acceleration.WDTY(marker1, marker2, marker3)

def WDTZ(marker1, marker2 = None, marker3 = None):
    """
    The z component of the relative angular acceleration between markers.
    :Input (marker1, marker2, marker3) : marker1, marker2 and marker3 are the names of action, base and reference markers. 
    :return: the z component of the vector can be returned
    """

    return Acceleration.WDTZ(marker1, marker2, marker3)