﻿import clr

clr.AddReference("VM.Post.API.Python")

from VM.Post.API.Python import GenericForce

def FM(marker1, marker2):
    """
    The magnitude of the force between markers.
    :Marker1 : the names or argument ids of action and base markers.
    :Marker2 : the names or argument ids of action and base markers.
    :return: the magnitude of the vector can be returned
    """
    return GenericForce.FM(marker1, marker2)

def FX(marker1, marker2, marker3 = None):
    """
    The x component of the force between markers.
    :Input (marker1, marker2, marker3) : marker1, marker2 and marker3 are the names of action, base and reference markers.
    :return: the x component of the vector can be returned
    """
    return GenericForce.FX(marker1, marker2, marker3)

def FY(marker1, marker2, marker3 = None):
    """
    The y component of the force between markers.
    :Input (marker1, marker2, marker3) : marker1, marker2 and marker3 are the names of action, base and reference markers.
    :return: the x component of the vector can be returned
    """
    return GenericForce.FY(marker1, marker2, marker3)

def FZ(marker1, marker2, marker3 = None):
    """
    The z component of the force between markers.
    :Input (marker1, marker2, marker3) : marker1, marker2 and marker3 are the names of action, base and reference markers.
    :return: the x component of the vector can be returned
    """
    return GenericForce.FZ(marker1, marker2, marker3)

def TM(marker1, marker2):
    """
    The magnitude of the torque between markers.
    :Input (marker1, marker2) : marker1 and marker2 are the names of action and base markers.
    :return: the magnitude of the vector can be returned
    """
    return GenericForce.TM(marker1, marker2)

def TX(marker1, marker2, marker3 = None):
    """
    The x component of the torque between markers.
    :Input (marker1, marker2, marker3) : marker1, marker2 and marker3 are the names of action, base and reference markers.
    :return: the x component of the vector can be returned
    """
    return GenericForce.TX(marker1, marker2, marker3)

def TY(marker1, marker2, marker3 = None):
    """
    The y component of the torque between markers.
    :Input (marker1, marker2, marker3) : marker1, marker2 and marker3 are the names of action, base and reference markers.
    :return: the x component of the vector can be returned
    """
    return GenericForce.TY(marker1, marker2, marker3)

def TZ(marker1, marker2, marker3 = None):
    """
    The z component of the torque between markers.
    :Input (marker1, marker2, marker3) : marker1, marker2 and marker3 are the names of action, base and reference markers.
    :return: the x component of the vector can be returned
    """
    return GenericForce.TZ(marker1, marker2, marker3)